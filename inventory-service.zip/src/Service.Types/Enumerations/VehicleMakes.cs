﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Service.Types.Enumerations
{
    public enum VehicleMakes
    {
        BMW,
        Honda,
        Mercedes
    }
}
