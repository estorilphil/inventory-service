﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Service.Types.Enumerations
{
    public enum TransmissionTypes
    {
        ConventionalAutomatic,
        ConventionalManual,
        SequentialManualSingleAutomaticCluctch,
        SequentialManualDualAutomaticClutch,
        SequentialManualTorqueConverter
    }
}
