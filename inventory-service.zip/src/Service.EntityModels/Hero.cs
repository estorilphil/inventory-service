﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Service.EntityModels
{
    public class Hero
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
